<?php



protected olarak tanımlaman gereken değişkenler $toplamsayi,$toplamSayfamiz,$limitimiz,$gosAdet;




function sayfalama ($deger1,$deger2) {
	
		$this->toplamsayi=$deger1; //**
		$this->gosAdet=$deger2; //**
			
		$this->toplamSayfamiz=ceil($deger1 / $this->gosAdet) + 1;			
		
			  						
		$sayfa=isset($_GET["hareket"]) ? (int) $_GET["hareket"] : 1;		
		if ($sayfa<1) $sayfa=1;				
		if ($sayfa > $this->toplamSayfamiz) $sayfa = $this->toplamSayfamiz;		
		$this->limitimiz=($sayfa - 1 ) * $this->gosAdet;	 //**	
	
	
	
}




function masayon ($vt) {
		
		
		
		if ($_POST):
		
		
		@$kategori=htmlspecialchars($_POST["kategori"]);
			
		
		
$this->sayfalama($this->genelsorgu($vt,"select * from masalar where kategori=$kategori")->num_rows,2);		
			
$so=$this->genelsorgu($vt,"select * from masalar where kategori=$kategori LIMIT ".$this->limitimiz.",".$this->gosAdet."");
	

		
				
		else:
		
		
				if (isset($_GET["Kategoriİd"])) :				
				
			$Sayfalamaicinid=$_GET["Kategoriİd"];
$this->sayfalama($this->genelsorgu($vt,"select * from masalar where kategori=$Sayfalamaicinid")->num_rows,2);		
			
$so=$this->genelsorgu($vt,"select * from masalar where kategori=$Sayfalamaicinid LIMIT ".$this->limitimiz.",".$this->gosAdet."");

				else:

		$this->sayfalama($this->genelsorgu($vt,"select * from masalar")->num_rows,5);		
			
$so=$this->genelsorgu($vt,"select * from masalar LIMIT ".$this->limitimiz.",".$this->gosAdet."");
				
				endif;
			
		
		
		
		endif;
		
		
echo '<table class="table text-center table-striped table-bordered mx-auto col-md-6 mt-4 table-dark " >
	<thead>
    <tr>
	<th>
	<form action="control.php?islem=masayon" method="post">
	
 	<select name="kategori" class="form-control">'; 	 
	 
	 foreach ($this->select as $key => $value) :
	 
	
				 
		 echo'<option value="'.$key.'" >'.$value.'</option>';
				 
			
	 
	 endforeach;
	 
	 
	echo'</select></th>
    <th ><input type="submit" name="arama" value="GETİR" class="btn btn-danger" /></form></th>    
    </tr>    
    </thead>
    </table>';
		
		
		
		
		
		echo '<table class="table text-center table-striped table-bordered mx-auto col-md-6 mt-4 " >
    <thead>
    <tr>
    <th scope="col"><a href="control.php?islem=masaekle" class="btn btn-success">+</a> Masa Adı</th>
	<th scope="col">Bölüm</th>
    <th scope="col">Güncelle</th>
    <th scope="col">Sil</th>    
    </tr>    
    </thead>
    <tbody>';
		
		while ($sonuc=$so->fetch_assoc()):
		
		echo '
    <tr>
    <td>'.$sonuc["ad"].'</td>';
	
	$this->BolumBilgiVer($vt,$sonuc["kategori"]);
	
	echo'<td><a href="control.php?islem=masaguncel&masaid='.$sonuc["id"].'" class="btn btn-warning">Güncelle </a></td>   
	<td><a href="control.php?islem=masasil&masaid='.$sonuc["id"].'" class="btn btn-danger" data-confirm="Masayı silmek istediğinize emin misiniz ?">Sil </a></td>        
    </tr>';
		
		endwhile;
		
		echo ' </tbody>
		
		
		<tr>
		
		<td colspan="5">
		<nav aria-label="Page navigation example">
		
				<ul class="pagination mx-auto">';
				
				
							
				if (isset($_GET["Kategoriİd"])) :				
				$link="control.php?islem=masayon&Kategoriİd=".$_GET["Kategoriİd"];				
				else:	
				
						if (@$kategori==""):
						$link="control.php?islem=masayon";		
						else:
						$link="control.php?islem=masayon&Kategoriİd=".@$kategori;		
						
						endif;
							
						
				endif;
				
			
				
				
				
					for ($s=1; $s<$this->toplamSayfamiz; $s++) :
						
						echo '<li class="page-item">
						
						<a class="page-link" href="'.$link.'&hareket='.$s.'">'.$s.'</a>
						
						
						
						</li>';
						
						endfor;
				
				
				
				
				
				
				
				
				echo '</ul></nav>
		
		
		</td>
		
		
		</tr>
		
		
    
    
    </table>';
		
		
		
	} // masa listele
	
	
	
	
	
	
	function urunyon ($vt,$tercih) {
				
				  
		 
		
		if ($tercih==1) :
		// arama kodları
		@$aramabuton=$_POST["aramabuton"];
		@$urun=$_POST["urun"];
		
		if ($aramabuton) :		
				
		
$this->sayfalama($this->genelsorgu($vt,"select * from urunler where ad LIKE '%$urun%'")->num_rows,2);		
			
$so=$this->genelsorgu($vt,"select * from urunler where ad LIKE '%$urun%' LIMIT ".$this->limitimiz.",".$this->gosAdet."");

else:

$SayfalamaAramaKelime=$_GET["AramaKelime"];

$this->sayfalama($this->genelsorgu($vt,"select * from urunler where ad LIKE '%$SayfalamaAramaKelime%'")->num_rows,2);		
			
$so=$this->genelsorgu($vt,"select * from urunler where ad LIKE '%$SayfalamaAramaKelime%' LIMIT ".$this->limitimiz.",".$this->gosAdet."");		
			
			
		
		endif;
	
		
		elseif ($tercih==2) :
		
		@$arama=$_POST["arama"];
		@$katid=$_POST["katid"];
		
		
		
		if ($arama) :		
					
				
$this->sayfalama($this->genelsorgu($vt,"select * from urunler where katid=$katid")->num_rows,2);		
			
$so=$this->genelsorgu($vt,"select * from urunler where katid=$katid LIMIT ".$this->limitimiz.",".$this->gosAdet."");	

	else:
	$Sayfalamaicinid=$_GET["Kategoriİd"];

$this->sayfalama($this->genelsorgu($vt,"select * from urunler where katid=$Sayfalamaicinid")->num_rows,2);		
			
$so=$this->genelsorgu($vt,"select * from urunler where katid=$Sayfalamaicinid LIMIT ".$this->limitimiz.",".$this->gosAdet."");	
			
				
		endif;	
		
		
		elseif ($tercih==3) :	
		
		$olcu=@$_GET["olcu"];
		
		
			
		$so=$this->genelsorgu($vt,"select * from urunler where stok<>0 order by stok $olcu;");	
		
		
		elseif ($tercih==0) :			
				
		$this->sayfalama($this->genelsorgu($vt,"select * from urunler")->num_rows,5);		
			
$so=$this->genelsorgu($vt,"select * from urunler LIMIT ".$this->limitimiz.",".$this->gosAdet."");
		
		
				
		endif;
		
		
		
		
		/*
		
		
		
			$gosterilecekadet=5;  // lımıt		
		$toplamsayfa=ceil($toplamicerik / $gosterilecekadet) + 1; // toplam sayfa sayımı belirledim						//  36 	  / 5   						
		$sayfa=isset($_GET["hareket"]) ? (int) $_GET["hareket"] : 1;		
		if ($sayfa<1) $sayfa=1;				
		if ($sayfa > $toplamsayfa) $sayfa = $toplamsayfa;		
		$limit=	($sayfa - 1 ) * $gosterilecekadet;	
		
		
		sayfa 1
		$limit=	($sayfa - 1 ) * $gosterilecekadet;	 lımıt değeri 0 olmuş olur.
						0     *      5
		
		sayfa 2
		$limit=	($sayfa - 1 ) * $gosterilecekadet;	 lımıt değeri 5 olmuş olur.
					1         *     5
		
		sayfa 3
		$limit=	($sayfa - 1 ) * $gosterilecekadet;	 lımıt değeri 10 olmuş olur.
					2         *     5
		sayfa 4
		$limit=	($sayfa - 1 ) * $gosterilecekadet;	lımıt değeri 15 olmuş olur.
					3         *     5
		
		
		
		$so=$this->genelsorgu($vt,"select * from urunler LIMIT $limit,$gosterilecekadet");
												1 sayfada		 0    5	
												 2 sayfada		 5    5	 kayıt ileri git
												 3 sayfada		 10    5	 kayıt ileri git 	
		*/		
		
		
		
		
		echo '<table class="table text-center table-striped table-bordered mx-auto col-md-7 mt-4 table-dark " >
	<thead>
    <tr>
    <th >
	<form action="control.php?islem=aramasonuc" method="post">	
	<input type="search" name="urun" class="form-control" placeholder="Aranacak ÜRÜN" /></th>
	<th ><input type="submit" name="aramabuton" value="ARA" class="btn btn-danger" /></form></th>	
    <th >
	<form action="control.php?islem=katgore" method="post">
	<select name="katid" class="form-control">';
	
	$d=$this->genelsorgu($vt,"select * from kategori");
	while ($katson=$d->fetch_assoc()) :	
	echo '
	<option value="'.$katson["id"].'">'.$katson["ad"].'</option>';	
	endwhile;  
    
  echo'  </select></th>
    <th ><input type="submit" name="arama" value="GETİR" class="btn btn-danger" /></form></th>    
    </tr>    
    </thead>
    </table>';
		
		echo ' <table class="table text-center table-striped table-bordered mx-auto col-md-7 mt-4 " >
	<thead>
    <tr>
    <th scope="col"><a href="control.php?islem=urunekle" class="btn btn-success">+</a> Ürün Adı</th>
	 <th scope="col">Ürün Fiyat</th>
	  <th scope="col"><a href="control.php?islem=siralama&olcu=desc"><i class="fas fa-arrow-up" style=font-size:12px;"></i></a> Ürün Stok   <a href="control.php?islem=siralama&olcu=asc"><i class="fas fa-arrow-down" style=font-size:12px;"></i></a></th>	
    <th scope="col">Güncelle</th>
    <th scope="col">Sil</th>    
    </tr>    
    </thead>
    <tbody>';
		
		while ($sonuc=$so->fetch_assoc()):
		
		echo '
    <tr>
    <td>'.$sonuc["ad"].'</td>
	 <td>'.$sonuc["fiyat"].'</td>
	 <td>'; 
	 
	 if ($sonuc["stok"]=="Yok") :
	 echo '<font class="text-danger">Yok</font>';
	 
	 else:
	 echo '<font class="text-success">'.$sonuc["stok"].'</font>';
	 
	 endif;
	 echo'</td>
	<td><a href="control.php?islem=urunguncel&urunid='.$sonuc["id"].'" class="btn btn-warning">Güncelle </a></td>   
	<td><a href="control.php?islem=urunsil&urunid='.$sonuc["id"].'" class="btn btn-danger" data-confirm="Ürünü silmek istediğinize emin misiniz ?">Sil </a></td>        
    </tr> ';		
		endwhile;		
		echo '</tbody>
		<tr>
		
		<td colspan="5">
		<nav aria-label="Page navigation example">
		
				<ul class="pagination mx-auto">';
				
				
				
				switch (@$_GET["islem"]) :
				
				case "urunyon":				
				$link="control.php?islem=urunyon";				
				break;
				
				case "katgore":				
				if (isset($_GET["Kategoriİd"])) :				
				$link="control.php?islem=katgore&Kategoriİd=".$_GET["Kategoriİd"];				
				else:				
				$link="control.php?islem=katgore&Kategoriİd=".$katid;				
				endif;
				
				
				break;
				
				case "aramasonuc":			
				
				if (isset($_GET["AramaKelime"])) :				
				$link="control.php?islem=aramasonuc&AramaKelime=".$_GET["AramaKelime"];				
				else:				
				$link="control.php?islem=aramasonuc&AramaKelime=".$urun;				
				endif;				
				break;
				
				endswitch;
				
				
				
					for ($s=1; $s<$this->toplamSayfamiz; $s++) :
						
						echo '<li class="page-item">
						
						<a class="page-link" href="'.$link.'&hareket='.$s.'">'.$s.'</a>
						
						
						
						</li>';
						
						endfor;
				
				
				
				
				
				
				
				
				echo '</ul></nav>
		
		
		</td>
		
		
		</tr>
		
		
		
		
		
		
		
		</table>';		
		
	} // ürün listele


?>